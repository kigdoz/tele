# Installation
> `npm install --save @types/tinycolor2`

# Summary
This package contains type definitions for tinycolor2 (https://github.com/bgrins/TinyColor).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/tinycolor2.

### Additional Details
 * Last updated: Wed, 18 Oct 2023 11:45:07 GMT
 * Dependencies: none

# Credits
These definitions were written by [Mordechai Zuber](https://github.com/M-Zuber), [Geert Jansen](https://github.com/geertjansen), and [Niels van Hoorn](https://github.com/nvh).
